from django.apps import AppConfig


class FooConfig(AppConfig):
    name = 'foo'
